Cats on a Lilypad Creature: The Cat Pack

An actor performed voice asset pack featuring 3 actors performing 7 different cat sounds. 

----

CONTENTS:
1 HAPPY MEOW 
2 ANGRY MEOW 
3 CONFUSED MEOW
4 HISS
5 CHATTER
6 GROWL
7 PURR


----


CREDIT:
KITTEN 1 - Marianne Bray  (https://twitter.com/KatteNoel)
CAT 1 - Katte Noel (https://twitter.com/MarianneDHobbit)
CAT 2 - Amanda Hufford (https://twitter.com/JustTheClippy)
CAT 3 - Kira Buckland (https://twitter.com/KiraBuckland)


Pack by Cats on a Lilypad Studios (https://twitter.com/CatsLilypad)
----

USER AGGREEMENT

This voice pack may be used for commercial or non-commercial projects.

Voice pack must not be used in explicit adult content, or in content featuring the likes of illegal activity, racism or hate speech.

To use this voice pack you must agree to provide credit to Cats on a Lilypad Studios and the Voice Actor who performed the sounds

We would also appreciate it if you left a link to the project you used the sounds in!


- Sample Credit -

VFX
The Cat Pack
Katte Noel, Kira Buckland
Cats on a Lilypad

- Sample Credit 2 -

Additional Voices
Kitten - Marianne Bray 

Effects
Cats on a Lilypad
